/***************************************************
  This is a library for our Adafruit FONA Cellular Module

  Designed specifically to work with the Adafruit FONA
  ----> http://www.adafruit.com/products/1946
  ----> http://www.adafruit.com/products/1963

  These displays use TTL Serial to communicate, 2 pins are required to
  interface
  Adafruit invests time and resources providing this open source code,
  please support Adafruit and open-source hardware by purchasing
  products from Adafruit!

  Written by Limor Fried/Ladyada for Adafruit Industries.
  BSD license, all text above must be included in any redistribution
 ****************************************************/
    // next line per http://postwarrior.com/arduino-ethershield-error-prog_char-does-not-name-a-type/

#include "Adafruit_FONA.h"




Adafruit_FONA::Adafruit_FONA(int8_t rst)
{
  _rstpin = rst;

  // apn = F("FONAnet");
  apn[0] = '\0';
  apnusername = 0;
  apnpassword = 0;
  mySerial = 0;
  httpsredirect = false;
  useragent = F("FONA");
  ok_reply = F("OK");
}

uint8_t Adafruit_FONA::type(void) {
  return _type;
}

boolean Adafruit_FONA::begin(Stream &port) {
	mySerial = &port;

	DEBUG_PRINTLN(F("Attempting to open comm with ATs"));
	// give 7 seconds to reboot
	int16_t timeout = 7000;

	while (timeout > 0) {
		while (mySerial->available()) mySerial->read(); //eat nonsense
		if (sendCheckReply(F("AT"), ok_reply))
			break;
		
		while (mySerial->available()) mySerial->read(); //eat nonsense
		if (sendCheckReply(F("AT"), F("AT"))) 
			break;
		
		delay(500);
		timeout-=500;
	}

	if (timeout <= 0) {

	sendCheckReply(F("AT"), ok_reply);
	delay(100);
	sendCheckReply(F("AT"), ok_reply);
	delay(100);
	sendCheckReply(F("AT"), ok_reply);
	delay(100);
	}

	// turn off Echo!
	sendCheckReply(F("ATE0"), ok_reply);
	delay(100);
	sendCheckReply(F("ATE0"), ok_reply);
	delay(50);
	sendCheckReply(F("ATE0"), ok_reply);
	delay(50);

 // if (! sendCheckReply(F("ATE0"), ok_reply)) {
  //  return false;
 // }
 // if (!setBaudratePerm(0)) {
//	  DEBUG_PRINTLN("COULD NOT SET BAUDRATE");
 //   return false;
//}
  //static_cast<HardwareSerial * >(mySerial)->begin(x);
  
	if (!setBaudrateTemp(9600)) {
		DEBUG_PRINTLN("COULD NOT SET BAUDRATE");
		return false;
	}
	static_cast<HardwareSerial * >(mySerial)->end();
	delay(20);
	static_cast<HardwareSerial * >(mySerial)->begin(9600);
	DEBUG_PRINTLN("New baudrate set to 9600 bps");
  // turn on hangupitude
 // if (_rstpin != 99) sendCheckReply(F("AT+CVHU=0"), ok_reply);

 // delay(100);
	flushInput();


  //DEBUG_PRINT(F("\t---> ")); DEBUG_PRINTLN("ATI");

  //mySerial->println("ATI");
 // readline(500, true);

 // DEBUG_PRINT (F("\t<--- ")); DEBUG_PRINTLN(replybuffer);

// #if defined(FONA_PREF_SMS_STORAGE)
    // sendCheckReply(F("AT+CPMS=" FONA_PREF_SMS_STORAGE "," FONA_PREF_SMS_STORAGE "," FONA_PREF_SMS_STORAGE), ok_reply);
// #endif

  //redirect URC messages "CPIN AVAILABLE", "SMS DONE", "PB DONE"
  uint8_t tries = 0;
  while (!sendCheckReply(F("AT+CATR=4"), ok_reply)){
	  tries++;
	  if (tries >= 3) return false; //break;  
  }
  return true;
}


/********* Serial port ********************************************/
//set baudrate permanently
boolean Adafruit_FONA::setBaudratePerm(uint16_t baud) {
  return sendCheckReply(F("AT+IPREX="), baud, ok_reply);
}

//set baudrate temporary
boolean Adafruit_FONA::setBaudrateTemp(uint16_t baud) {
  return sendCheckReply(F("AT+IPR="), baud, ok_reply);
}


/********* POWER, BATTERY & ADC ********************************************/
/* powers down the SIM module */
boolean Adafruit_FONA::powerDown(void) {
    if (! sendCheckReply(F("AT+CPOF"), ok_reply))
      return false;
	return true;
}


/********* SIM and NETWORK***********************************************************/

uint8_t Adafruit_FONA::unlockSIM(const char *pin)
{
  char sendbuff[14] = "AT+CPIN=";
  sendbuff[8] = pin[0];
  sendbuff[9] = pin[1];
  sendbuff[10] = pin[2];
  sendbuff[11] = pin[3];
  sendbuff[12] = '\0';

  return sendCheckReply(sendbuff, ok_reply);
}


uint8_t Adafruit_FONA::CheckSysInfo(FONAFlashStringPtr send, char* reply, uint8_t len) {
	uint8_t readbytes = getReply(send);
	
	if (readbytes <= 0) {
		//DEBUG_PRINTLN("Could not request sys info");
		return 0;
	}

	//DEBUG_PRINT("replybuffer: "); DEBUG_PRINTLN(replybuffer);

	char* c = strchr(replybuffer, ':'); //now i holds prt_index to first part of reply.
	if (c == NULL) {
		DEBUG_PRINTLN("Could not parse sys info");
		return 0;
	}
	c += 2; //increment 2 to move to first char of reply
	
	//uint8_t str_len = strlen(c);
	//DEBUG_PRINT(F("strlen: ")); DEBUG_PRINTLN(str_len);
	
	readline(5000); //eat OK
	int n = snprintf(reply, len, "%s", c);
	if (n <= 0) return 0;
	
	return readbytes;
}


uint8_t Adafruit_FONA::getNetworkStatus(void) {
  uint16_t status;

  if (! sendParseReply(F("AT+CREG?"), F("+CREG: "), &status, ',', 1)) return 0;

  return status;
}

uint8_t Adafruit_FONA::getRSSI(void) {
  uint16_t reply;

  if (! sendParseReply(F("AT+CSQ"), F("+CSQ: "), &reply) ) return 0;

  return reply;
}



//call immedeately at startup
boolean Adafruit_FONA::CheckModuleON(){
	unsigned long start = millis();
	readline(5000);
	while(strcmp(replybuffer, "PB DONE") != 0){
		DEBUG_PRINT("message: "); DEBUG_PRINTLN(replybuffer);
	//	DEBUG_PRINTLN("Not yet on");
		if((start + 20000) < millis()) return false;  //wait max 20 s for module to poweron
		readline(5000);
	}
	DEBUG_PRINTLN("Module is powered on");
	return true;	
}

/********* IMEI **********************************************************/

uint8_t Adafruit_FONA::getIMEI(char *imei) {
  getReply(F("AT+GSN"));

  // up to 15 chars
  strncpy(imei, replybuffer, 15);
  imei[15] = 0;

  readline(); // eat 'OK'

  return strlen(imei);
}



/********* TIME **********************************************************/
int8_t Adafruit_FONA::SetNTP(const char* ntpserver, int8_t timezone) {

    mySerial->print(F("AT+CNTP=\""));
	DEBUG_PRINT("AT+CNTP=\"");
    if (ntpserver != 0) {
      mySerial->print(ntpserver);
	  DEBUG_PRINT(ntpserver);
    } else {
      mySerial->print(F("pool.ntp.org"));
	  DEBUG_PRINT("pool.ntp.org");
    }
    mySerial->print(F("\","));
	mySerial->println(timezone * 4);
	DEBUG_PRINT("\",");
	DEBUG_PRINTLN(timezone * 4);
	
    readline(FONA_DEFAULT_TIMEOUT_MS);
	DEBUG_PRINTLN();
	DEBUG_PRINT("at+cntp=server,timezone reply:"); DEBUG_PRINTLN(replybuffer);
	
    if (strcmp(replybuffer, "OK") != 0)
      return -1;
  
	DEBUG_PRINTLN("Done setting NTP server, now updating");
	return updateNTPTime();
}

int8_t Adafruit_FONA::updateNTPTime(){
	//update time
    if (! sendCheckReply(F("AT+CNTP"), ok_reply, 10000))
      return -1;
	DEBUG_PRINTLN("Got OK from AT+CNTP");
	
	//request time
    uint16_t status;
    readline(10000); 
    if (!parseReply(F("+CNTP:"), &status))
      return -1;
  DEBUG_PRINT("status from updating time: "); DEBUG_PRINTLN(status);
  return (uint8_t)status;
}

////HTP
int8_t Adafruit_FONA::SetHTP(const char* htpserver) {/////TODO
  if(!htpserver) return -1;

  char cmd[255];
  snprintf(cmd, sizeof cmd, "AT+CHTPSERV=\"ADD\",\"%s\",80,1", htpserver);
  DEBUG_PRINT("complete HTP set cmd: "); DEBUG_PRINTLN(cmd);
  if (!sendCheckReply(cmd, "OK", 5000)) {
	return -1;
    DEBUG_PRINTLN("could not set HTP server");
  }
  
//AT+CHTPSERV="ADD","www.google.com",80,1
 /*   if (htpserver != 0) {
	  mySerial->print(F("AT+CHTPSERVER=\"ADD\",\""));
      DEBUG_PRINT("AT+CHTPSERV=\"ADD\",\"");
      mySerial->print(htpserver);
	  DEBUG_PRINT(htpserver);
	  mySerial->println(F("\",80,1"));
	  DEBUG_PRINTLN("\",80,1");
    } else {
	  DEBUG_PRINTLN("False HTP serveraddress");
    }	
    readline(FONA_DEFAULT_TIMEOUT_MS);
	DEBUG_PRINT("AT+CHTPSERV= -> reply:"); DEBUG_PRINTLN(replybuffer);
	
    if (strcmp(replybuffer, "OK") != 0)
      return -1;
*/
	DEBUG_PRINTLN("Done setting HTP server");
	return 0;//updateHTPTime();
}
int8_t Adafruit_FONA::updateHTPTime(){
	//check if module has finished updating
	for( int i =0; i<5;i++){
		if (! sendCheckReply(F("AT+CHTPUPDATE?"), F("+CHTPUPDATE: NULL"), 2000)){
			DEBUG_PRINTLN("updating htp");		
			if(i<5){
				continue;
			} 
			else{
				return -1; 	 
			}	
		}
		else{
			break;
		}
	}	
	
    //if (! sendCheckReply(F("AT+CHTPUPDATE"), F("OK"), 7000)){
	//	DEBUG_PRINTLN("could not update HTP server");
	//	return -1; 	  
	//}
	//DEBUG_PRINTLN("Got OK from AT+CHTPUPDATE");
	
			//getReply(F("AT+CHTPUPDATE"), (uint16_t) 10000);
			mySerial->println(F("AT+CHTPUPDATE"));
			DEBUG_PRINTLN("\t---> AT+CHTPUPDATE");
			
			//DEBUG_PRINT("readline buffer:"); DEBUG_PRINTLN(replybuffer);
			//return 0;

	//request time
    uint16_t status;
    readline(5000, true);
	DEBUG_PRINT("readline buffer:"); DEBUG_PRINTLN(replybuffer);
	readline(15000, true);	
	DEBUG_PRINT("readline buffer:"); DEBUG_PRINTLN(replybuffer);
    if (!parseReply(F("+CHTPUPDATE: "), &status)){
      return -1;
	}
	DEBUG_PRINT("status from updating HTP time: "); DEBUG_PRINTLN(status);
	return (uint8_t)status;
}

//Get time from internal SIM-RTC-module
int8_t Adafruit_FONA::getTime(char* timenow, uint16_t maxlen) {
	uint8_t status = updateHTPTime();
	if(status == 0){ //status 0 means update succes
	  getReply(F("AT+CCLK?"), (uint16_t) 10000);
	  if (strncmp(replybuffer, "+CCLK: ", 7) != 0)
		return -1;

	  char *p = replybuffer+7;
	  uint16_t lentocopy = min(maxlen-1, strlen(p));
	  strncpy(timenow, p, lentocopy+1);
	  timenow[lentocopy] = 0;

	  readline(); // eat OK
	}
  return status;
}

/*[2018-11-06_10:46:59]AT+CNTP="0.pool.ntp.org",4

[2018-11-06_10:46:59]OK
[2018-11-06_10:47:07]AT+CNTP

[2018-11-06_10:47:07]OK
[2018-11-06_10:47:07]
[2018-11-06_10:47:07]+CNTP: 0
[2018-11-06_10:47:17]AT+CCLK

[2018-11-06_10:47:17]ERROR
[2018-11-06_10:47:20]AT+CCLK?

[2018-11-06_10:47:20]+CCLK: "18/11/06,10:47:21+04"

[2018-11-06_10:47:20]OK
*/





/********* GPRS **********************************************************/


boolean Adafruit_FONA::OpenInternet(boolean onoff) {
	if (onoff) {
		if (! sendCheckReply(F("AT+CGATT=1"), ok_reply, 10000))  return false;
	  
		//DEBUG_PRINT("APN:"); DEBUG_PRINTLN(apn);
		
		

		// set bearer profile access point name
		if (apn) {
		  //DEBUG_PRINTLN("1");
		  //DEBUG_PRINT("APN:"); DEBUG_PRINTLN(apn);
		  flushInput();
		  if (! sendCheckReplyQuoted("AT+CGDCONT=1,\"IP\",", apn, ok_reply, 10000)) return false;
		 // DEBUG_PRINTLN("2");
		  flushInput();
		  if (! sendCheckReplyQuoted("AT+CGSOCKCONT=1,\"IP\",", apn, ok_reply, 10000)) return false;
			flushInput();
		  // set username/password
		  if (apnusername) {
			char authstring[100] = "AT+CGAUTH=1,1,\"";
			// char authstring[100] = "AT+CSOCKAUTH=1,1,\""; // For 3G
			char *strp = authstring + strlen(authstring);
			prog_char_strcpy(strp, (prog_char *)apnusername);
			strp+=prog_char_strlen((prog_char *)apnusername);
			strp[0] = '\"';
			strp++;
			strp[0] = 0;
		  
			if (apnpassword) {
			  strp[0] = ','; strp++;
			  strp[0] = '\"'; strp++;
			  prog_char_strcpy(strp, (prog_char *)apnpassword);
			  strp+=prog_char_strlen((prog_char *)apnpassword);
			  strp[0] = '\"';
			  strp++;
			  strp[0] = 0;
			}
		  
			if (! sendCheckReply(authstring, ok_reply, 10000))
			  return false;
		  }
		}
	

		flushInput();
		int buff_len = 32;
		char buff[buff_len];
		if (!getReplyPrt(F("AT+NETOPEN?"), buff,   1, buff_len)){
			DEBUG_PRINTLN("not req 1 1");
			return false;
		}
		long stat_l = strtol(buff, NULL, 0);
		DEBUG_PRINT("stat:"); DEBUG_PRINTLN(stat_l);
		if(stat_l != 1){
			DEBUG_PRINTLN("not 1 or 0, so opening");
			if (! sendCheckReply(F("AT+NETOPEN"), F("OK"), 10000))			//open
				return false;
			readline(); //eat status (for now)
		}
		
		
		if (!getReplyPrt(F("AT+CNETSTART?"), buff,   1, buff_len)){
			DEBUG_PRINTLN("not req 1");
			return false;
		}	
		stat_l = strtol(buff, NULL, 0);
		DEBUG_PRINT("stat:"); DEBUG_PRINTLN(stat_l);
		if(stat_l != 2){
			DEBUG_PRINTLN("not 2, so opening");
			if (! sendCheckReply(F("AT+CNETSTART"), F("OK"), 10000)){			//open
				if (!getReplyPrt(F("AT+CNETSTART?"), buff,   1, buff_len)){
					DEBUG_PRINTLN("not req 1");
					return false;
				}	
				stat_l = strtol(buff, NULL, 0);
				DEBUG_PRINT("stat:"); DEBUG_PRINTLN(stat_l);
				if(stat_l != 2){
					DEBUG_PRINTLN("not 2, so opening");
					readline(); //eat status (for now)
					return false;
				}
				return true;
			}
		}	
	} else{
		getReply(F("AT+NETCLOSE"));
		getReply(F("AT+CNETSTOP"));
		getReply(F("AT+CHTTPSSTOP"));
		// getReply(F("AT+CHTTPSCLSE"));

			// if (! sendCheckReply(F("AT+NETCLOSE"), ok_reply, 10000))
			//	return false;
			// 	if (! sendCheckReply(F("AT+CHTTPSSTOP"), F("+CHTTPSSTOP: 0"), 10000))
			// 	return false;
			//	if (! sendCheckReply(F("AT+CHTTPSCLSE"), ok_reply, 10000))
			// 	return false;
		

		readline(); // eat 'OK'
	  }
	
	return true;
}

void Adafruit_FONA::getNetworkInfo(void) {
	getReply(F("AT+CPSI?"));
	getReply(F("AT+COPS?"));
}

uint8_t Adafruit_FONA::GPRSstate(void) {
  uint16_t state;

  if (! sendParseReply(F("AT+CGATT?"), F("+CGATT: "), &state) )
    return -1;

  return state;
}

void Adafruit_FONA::setNetworkSettings(const char * _apn,
              FONAFlashStringPtr username, FONAFlashStringPtr password) {
  // strcpy(apn, _apn);
  snprintf(apn, 64, "%s", _apn);
  //DEBUG_PRINT("APN SET:"); DEBUG_PRINTLN(apn);
  this->apnusername = username;
  this->apnpassword = password;
}



	
/********* HTTP *********************************************/
/*void Adafruit_FONA::CreateAuthString(char *auth_cmd, int len) {
  //first create auth string;
  char auth[255]; //maybe reduce size

  snprintf(auth, sizeof auth, "%s:%s", server_auth_username, server_auth_password);

  rbase64.encode(auth);
  // DEBUG_PRINT("auth string: "); DPRINT(auth); DPRINT("=");
  // DEBUG_PRINTLN(rbase64.result());

  memset(auth, 0, strlen(auth));
  snprintf(auth, sizeof auth, "Authorization: Basic %s", rbase64.result());
  //DEBUG_PRINT("complete auth string: "); DPRINTLN(auth);

  snprintf(auth_cmd, len, "AT+HTTPPARA=\"USERDATA\",\"%s\"", auth);
}
*/

boolean Adafruit_FONA::HTTPPOST(char* measurement_data, int json_len, const char* url, const char* token, int token_len) {
  if (!sendCheckReply(F("AT+HTTPINIT"), F("OK"), 50000)) {
   // DEBUG_PRINTLN("could not HTTPINIT");
   // DEBUG_PRINTLN("trying to init HTTP service");
    CloseHTTP();
    if (!sendCheckReply(F("AT+HTTPINIT"), F("OK"), 50000)) {
  //    DEBUG_PRINTLN("could not HTTPINIT, closing");
      CloseHTTP();
      return false;
    }
  }
  
  //ACCEPT JSON Server
  if (!sendCheckReply(F("AT+HTTPPARA=\"ACCEPT\",\"application/json\""), F("OK"), 50000)) {
      DEBUG_PRINTLN("could not set , closing");
      CloseHTTP();
      return false;
    }
  
  //Does not work with long auth header
 /* char auth_cmd[512];
  snprintf(auth_cmd, sizeof auth_cmd, "AT+HTTPPARA=\"USERDATA\",\"Authorization: Bearer %s\"", token);
  //DEBUG_PRINT("complete auth_command: "); DEBUG_PRINTLN(auth_cmd);
  if (!sendCheckReply(auth_cmd, "OK", 10000)) {
 //   DEBUG_PRINTLN("could not HTTP USERDATA AUTH");
    CloseHTTP();
    return false;
  }
  */
  
  //send authorization header
  char authkey_cmd[32];
  snprintf(authkey_cmd, sizeof authkey_cmd, "AT+HTTPAUTHKEY=%d", token_len);
  //DEBUG_PRINT("complete set_authkey_cmd: "); DEBUG_PRINTLN(authkey_cmd);
  if (!sendCheckReply(authkey_cmd, "DOWNLOAD", 10000)) {
    DEBUG_PRINTLN("could not set authkey_cmd");
    CloseHTTP();
    return false;
  }
  char _token[512];
  snprintf(_token, sizeof _token, token);
  if(!sendCheckReply(_token, ok_reply, 3000)) {
    //in case of not calculated correct token length, send "\r\n"
		boolean complete = false;
		for (int i = 0; i < (json_len / 2); i++) {
			mySerial->println();
			if (expectReply(F("OK")),100) {
				complete = true;
				break;
			}
		}
		if(!complete){
			CloseHTTP();
			return false;
		}
	}
  

  if (!sendCheckReply(F("AT+HTTPPARA=\"CONTENT\",\"application/json\""), F("OK"), 10000)) {
  //  DEBUG_PRINTLN("could not CONTENT application/json");
    CloseHTTP();
    return false;
  }
	
	
  char url_cmd[255];
  snprintf(url_cmd, sizeof url_cmd, "AT+HTTPPARA=\"URL\",\"%s\"", url);
  
  if (!sendCheckReply(url_cmd, "OK", 10000)) {
  //  DEBUG_PRINTLN("could not set URL");
    CloseHTTP();
    return false;
  }


  //send at+data
  //AT+HTTPDATA=50,10000
  char data_cmd[32];
  snprintf(data_cmd, sizeof data_cmd, "AT+HTTPDATA=%d,10000", json_len);
  //DEBUG_PRINT("complete set_data_command: "); DEBUG_PRINTLN(data_cmd);
  if (!sendCheckReply(data_cmd, "DOWNLOAD", 10000)) {
    DEBUG_PRINTLN("could not set Data");
    CloseHTTP();
    return false;
  }

  //send json
	// json_data_object->PrintTo(mySerial);
	if(!sendCheckReply(measurement_data, ok_reply, 3000)) {
    //in case of not set buffer length is send to module send "\r\n"
		boolean complete = false;
		for (int i = 0; i < (json_len / 2); i++) {
			mySerial->println();
			if (expectReply(F("OK")),100) {
				complete = true;
				break;
			}
		}
		if(!complete){
			CloseHTTP();
			return false;
		}
	}

  //send HTTPaction=1, check ok
  if (!sendCheckReply(F("AT+HTTPACTION=1"), F("OK"), 10000)) {
    CloseHTTP();
    return false;
  }

  //read reply -> ex. "+HTTPACTION:1,200,46"
  //char buff[255];
  //TODO: make readline >0 ifstatement
  if (readline(30000, false) > 0){ //can take up to 30s for response
	DEBUG_PRINT("Reply from server: "); DEBUG_PRINTLN(replybuffer);

	char status_code_c[128];
	char bytes_c[128];
	extractReply(replybuffer, bytes_c, 3, 128);
	extractReply(replybuffer, status_code_c, 2, 128);

	long bytes_l = strtol(bytes_c, NULL, 0);
	long status_code_l = strtol(status_code_c, NULL, 0);
	// DEBUG_PRINT("bytes_l:"); DEBUG_PRINTLN(bytes_l);
	// DEBUG_PRINT("status_code_l:"); DEBUG_PRINTLN(status_code_l);

	if (status_code_l == 200) {
		//DEBUG_PRINTLN("OK 200 POST succes!");
		DEBUG_PRINTLN("Message succesfully send to server");
		//complete message sent, now try to close HTTPServie
		return CloseHTTP();
	}
	else if (status_code_l == 500) {
		DEBUG_PRINTLN("Server error");
	}
  }
  else{
	DEBUG_PRINTLN("No, response within 30s, giving up");
  }
  CloseHTTP();
  return false;
}

boolean Adafruit_FONA::CloseHTTP() {
  if (!sendCheckReply(F("AT+HTTPTERM"), F("OK"), 10000)) {
    DEBUG_PRINTLN("could not set HTTPTERM");
    return false;
  }
  return true;
}
/*****************HTTP**************/









/********* HELPERS *********************************************/

boolean Adafruit_FONA::expectReply(FONAFlashStringPtr reply,
                                   uint16_t timeout) {
  readline(timeout);

  DEBUG_PRINT(F("\t<--- ")); DEBUG_PRINTLN(replybuffer);

  return (prog_char_strcmp(replybuffer, (prog_char*)reply) == 0);
}

/********* LOW LEVEL *******************************************/

inline int Adafruit_FONA::available(void) {
  return mySerial->available();
}

inline size_t Adafruit_FONA::write(uint8_t x) {
  return mySerial->write(x);
}

inline int Adafruit_FONA::read(void) {
  return mySerial->read();
}

inline int Adafruit_FONA::peek(void) {
  return mySerial->peek();
}

inline void Adafruit_FONA::flush() {
  mySerial->flush();
}

void Adafruit_FONA::flushInput() {
    // Read all available serial input to flush pending data.
    uint16_t timeoutloop = 0;
    while (timeoutloop++ < 40) {
        while(available()) {
            read();
            timeoutloop = 0;  // If char was received reset the timer
        }
        delay(1);
    }
}







//send send string and check response. prt_index indicates which part of the reply is returned to 'char* reply',
//prt_index=1 --> return first part after ':' and till divider ',' 
//prt_index=2 --> return second part after ':' and till divider ',' 
uint8_t Adafruit_FONA::getReplyPrt(FONAFlashStringPtr send, char* reply, uint8_t prt_index, uint8_t len) {
	uint8_t readbytes = getReply(send);
	//DEBUG_PRINT(F("readbytes raw: ")); DEBUG_PRINTLN(readbytes);
	
	
	if (readbytes<=0)
	{
		DEBUG_PRINTLN(F("no response..."));
		return false;
	}
	char* c = strchr(replybuffer, ':'); //now i holds prt_index to first part of reply.
	//DEBUG_PRINTLN(c);
	if (c == NULL) return false;
	c += 2; //increment 2 to move to first char of reply
	
	return extractReply(c, reply, prt_index, len);
}

uint8_t Adafruit_FONA::extractReply(char* in, char* out, uint8_t prt_index, uint8_t len){
	uint8_t reply_idx = 0;
	uint8_t reply_prt = 1;
	uint8_t i = 0;
	uint8_t str_len = strlen(in);
	
	//DEBUG_PRINT(F("strlen: ")); DEBUG_PRINTLN(str_len);
	for (i=0; i<str_len; i++){
		if(in[i] == ','){
			reply_prt++;
			//DEBUG_PRINT(F("replypart: ")); DEBUG_PRINTLN(reply_prt);
			if(reply_prt > prt_index) break;
			else continue;
		}
		
		if(reply_prt == prt_index){
			
			if(i >= len-1) break; //end of string or end of buffersize
			//DEBUG_PRINT(F("char: ")); DEBUG_PRINTLN(in[i]);
			out[reply_idx++] = in[i];
		}	
	}
	out[reply_idx] = '\0'; //zero terminate string
	//DEBUG_PRINT(F("read bytes (-1): ")); DEBUG_PRINTLN(reply_idx);
	return reply_idx;
}
















uint16_t Adafruit_FONA::readRaw(uint16_t b) {
  uint16_t idx = 0;

  while (b && (idx < sizeof(replybuffer)-1)) {
    if (mySerial->available()) {
      replybuffer[idx] = mySerial->read();
      idx++;
      b--;
    }
  }
  replybuffer[idx] = 0;

  return idx;
}

uint8_t Adafruit_FONA::ReadlineReturn(char *buff, uint8_t len, uint16_t timeout) {
  uint16_t buffidx = 0;
  boolean timeoutvalid = true;
  if (timeout == 0) timeoutvalid = false;

  while (true) {
    if (buffidx > len) {
      //mySerial->println(F("SPACE"));
      break;
    }

    while (mySerial->available()) {
      char c =  mySerial->read();

      // should be debug prints: mySerial->print(c, HEX); mySerial->print("#"); mySerial->println(c);

      if (c == '\r') continue;
      if (c == 0xA) {
        if (buffidx == 0)   // the first 0x0A is ignored
          continue;

        timeout = 0;         // the second 0x0A is the end of the line
        timeoutvalid = true;
        break;
      }
      buff[buffidx] = c;
      buffidx++;
    }

    if (timeoutvalid && timeout == 0) {
      //mySerial->println(F("TIMEOUT"));
      break;
    }
    delay(1);
  }
  buff[buffidx] = 0;  // null term
  mySerial->print("buffidx"); mySerial->println(buffidx);
  return buffidx;
}

uint8_t Adafruit_FONA::readline(uint16_t timeout, boolean multiline) {
  uint16_t replyidx = 0;

  while (timeout--) {
    if (replyidx >= 254) {
      //DEBUG_PRINTLN(F("SPACE"));
      break;
    }

    while(mySerial->available()) {
      char c =  mySerial->read();
      if (c == '\r') continue;
      if (c == 0xA) {
        if (replyidx == 0)   // the first 0x0A is ignored
          continue;

        if (!multiline) {
          timeout = 0;         // the second 0x0A is the end of the line
          break;
        }
      }
      replybuffer[replyidx] = c;
      //DEBUG_PRINT(c, HEX); DEBUG_PRINT("#"); DEBUG_PRINTLN(c);
      replyidx++;
    }

    if (timeout == 0) {
      //DEBUG_PRINTLN(F("TIMEOUT"));
      break;
    }
    delay(1);
  }
  replybuffer[replyidx] = 0;  // null term
  return replyidx;
}

uint8_t Adafruit_FONA::getReply(char *send, uint16_t timeout) {
  flushInput();


  DEBUG_PRINT(F("\t---> ")); DEBUG_PRINTLN(send);


  mySerial->println(send);

  uint8_t l = readline(timeout);

  DEBUG_PRINT (F("\t<--- ")); DEBUG_PRINTLN(replybuffer);

  return l;
}

uint8_t Adafruit_FONA::getReply(FONAFlashStringPtr send, uint16_t timeout) {
  flushInput();


	DEBUG_PRINT(F("\t---> ")); DEBUG_PRINTLN(send);
	//Debug.print(F("\t---> ")); Debug.println(send);


  mySerial->println(send);

  uint8_t l = readline(timeout);

  DEBUG_PRINT (F("\t<--- ")); DEBUG_PRINTLN(replybuffer);

  return l;
}

// Send prefix, suffix, and newline. Return response (and also set replybuffer with response).
uint8_t Adafruit_FONA::getReply(FONAFlashStringPtr prefix, char *suffix, uint16_t timeout) {
  flushInput();


  DEBUG_PRINT(F("\t---> ")); DEBUG_PRINT(prefix); DEBUG_PRINTLN(suffix);


  mySerial->print(prefix);
  mySerial->println(suffix);

  uint8_t l = readline(timeout);

  DEBUG_PRINT (F("\t<--- ")); DEBUG_PRINTLN(replybuffer);

  return l;
}

// Send prefix, suffix, and newline. Return response (and also set replybuffer with response).
uint8_t Adafruit_FONA::getReply(FONAFlashStringPtr prefix, int32_t suffix, uint16_t timeout) {
  flushInput();


 // DEBUG_PRINT(F("\t---> ")); DEBUG_PRINT(prefix); DEBUG_PRINTLN(suffix, DEC);


  mySerial->print(prefix);
  mySerial->println(suffix, DEC);

  uint8_t l = readline(timeout);

  DEBUG_PRINT (F("\t<--- ")); DEBUG_PRINTLN(replybuffer);

  return l;
}

// Send prefix, suffix, suffix2, and newline. Return response (and also set replybuffer with response).
uint8_t Adafruit_FONA::getReply(FONAFlashStringPtr prefix, int32_t suffix1, int32_t suffix2, uint16_t timeout) {
  flushInput();


 // DEBUG_PRINT(F("\t---> ")); DEBUG_PRINT(prefix);
 // DEBUG_PRINT(suffix1, DEC); DEBUG_PRINT(','); DEBUG_PRINTLN(suffix2, DEC);


  mySerial->print(prefix);
  mySerial->print(suffix1);
  mySerial->print(',');
  mySerial->println(suffix2, DEC);

  uint8_t l = readline(timeout);

  DEBUG_PRINT (F("\t<--- ")); DEBUG_PRINTLN(replybuffer);

  return l;
}

// Send prefix, ", suffix, ", and newline. Return response (and also set replybuffer with response).
uint8_t Adafruit_FONA::getReplyQuoted(char *prefix, char *suffix, uint16_t timeout) {
  flushInput();


  DEBUG_PRINT(F("\t---> ")); DEBUG_PRINT(prefix);
  DEBUG_PRINT('"'); DEBUG_PRINT(suffix); DEBUG_PRINTLN('"');


  mySerial->print(prefix);
  mySerial->print('"');
  mySerial->print(suffix);
  mySerial->println('"');

  uint8_t l = readline(timeout);

  DEBUG_PRINT (F("\t<--- ")); DEBUG_PRINTLN(replybuffer);

  return l;
}


boolean Adafruit_FONA::sendCheckReply(char *send, char *reply, uint16_t timeout) {
  if (! getReply(send, timeout) )
	  return false;
/*
  for (uint8_t i=0; i<strlen(replybuffer); i++) {
  DEBUG_PRINT(replybuffer[i], HEX); DEBUG_PRINT(" ");
  }
  DEBUG_PRINTLN();
  for (uint8_t i=0; i<strlen(reply); i++) {
    DEBUG_PRINT(reply[i], HEX); DEBUG_PRINT(" ");
  }
  DEBUG_PRINTLN();
  */
  return (strcmp(replybuffer, reply) == 0);
}

boolean Adafruit_FONA::sendCheckReply(FONAFlashStringPtr send, FONAFlashStringPtr reply, uint16_t timeout) {
	if (! getReply(send, timeout) )
		return false;

  return (prog_char_strcmp(replybuffer, (prog_char*)reply) == 0);
}

boolean Adafruit_FONA::sendCheckReply(char* send, FONAFlashStringPtr reply, uint16_t timeout) {
  if (! getReply(send, timeout) )
	  return false;
  return (prog_char_strcmp(replybuffer, (prog_char*)reply) == 0);
}


// Send prefix, suffix, and newline.  Verify FONA response matches reply parameter.
boolean Adafruit_FONA::sendCheckReply(FONAFlashStringPtr prefix, char *suffix, FONAFlashStringPtr reply, uint16_t timeout) {
  getReply(prefix, suffix, timeout);
  return (prog_char_strcmp(replybuffer, (prog_char*)reply) == 0);
}

// Send prefix, suffix, and newline.  Verify FONA response matches reply parameter.
boolean Adafruit_FONA::sendCheckReply(FONAFlashStringPtr prefix, int32_t suffix, FONAFlashStringPtr reply, uint16_t timeout) {
  getReply(prefix, suffix, timeout);
  return (prog_char_strcmp(replybuffer, (prog_char*)reply) == 0);
}

// Send prefix, suffix, suffix2, and newline.  Verify FONA response matches reply parameter.
boolean Adafruit_FONA::sendCheckReply(FONAFlashStringPtr prefix, int32_t suffix1, int32_t suffix2, FONAFlashStringPtr reply, uint16_t timeout) {
  getReply(prefix, suffix1, suffix2, timeout);
  return (prog_char_strcmp(replybuffer, (prog_char*)reply) == 0);
}

// Send prefix, ", suffix, ", and newline.  Verify FONA response matches reply parameter.
boolean Adafruit_FONA::sendCheckReplyQuoted(char *prefix, char *suffix, FONAFlashStringPtr reply, uint16_t timeout) {
  getReplyQuoted(prefix, suffix, timeout);
  return (prog_char_strcmp(replybuffer, (prog_char*)reply) == 0);
}


boolean Adafruit_FONA::parseReply(FONAFlashStringPtr toreply,
          uint16_t *v, char divider, uint8_t index) {
  char *p = prog_char_strstr(replybuffer, (prog_char*)toreply);  // get the pointer to the voltage
  if (p == 0) return false;
  p+=prog_char_strlen((prog_char*)toreply);
  DEBUG_PRINTLN(p);
  for (uint8_t i=0; i<index;i++) {
    // increment dividers
    p = strchr(p, divider);
    if (!p) return false;
    p++;
    DEBUG_PRINTLN(p);

  }
  *v = atoi(p);

  return true;
}

boolean Adafruit_FONA::parseReply(FONAFlashStringPtr toreply,
          char *v, char divider, uint8_t index) {
  uint8_t i=0;
  char *p = prog_char_strstr(replybuffer, (prog_char*)toreply);
  if (p == 0) return false;
  p+=prog_char_strlen((prog_char*)toreply);

  for (i=0; i<index;i++) {
    // increment dividers
    p = strchr(p, divider);
    if (!p) return false;
    p++;
  }

  for(i=0; i<strlen(p);i++) {
    if(p[i] == divider)
      break;
    v[i] = p[i];
  }

  v[i] = '\0';

  return true;
}

// Parse a quoted string in the response fields and copy its value (without quotes)
// to the specified character array (v).  Only up to maxlen characters are copied
// into the result buffer, so make sure to pass a large enough buffer to handle the
// response.
boolean Adafruit_FONA::parseReplyQuoted(FONAFlashStringPtr toreply,
          char *v, int maxlen, char divider, uint8_t index) {
  uint8_t i=0, j;
  // Verify response starts with toreply.
  char *p = prog_char_strstr(replybuffer, (prog_char*)toreply);
  if (p == 0) return false;
  p+=prog_char_strlen((prog_char*)toreply);

  // Find location of desired response field.
  for (i=0; i<index;i++) {
    // increment dividers
    p = strchr(p, divider);
    if (!p) return false;
    p++;
  }

  // Copy characters from response field into result string.
  for(i=0, j=0; j<maxlen && i<strlen(p); ++i) {
    // Stop if a divier is found.
    if(p[i] == divider)
      break;
    // Skip any quotation marks.
    else if(p[i] == '"')
      continue;
    v[j++] = p[i];
  }

  // Add a null terminator if result string buffer was not filled.
  if (j < maxlen)
    v[j] = '\0';

  return true;
}

boolean Adafruit_FONA::sendParseReply(FONAFlashStringPtr tosend,
				      FONAFlashStringPtr toreply,
				      uint16_t *v, char divider, uint8_t index) {
  getReply(tosend);

  if (! parseReply(toreply, v, divider, index)) return false;

  readline(); // eat 'OK'

  return true;
}

boolean Adafruit_FONA::parseReplyFloat(FONAFlashStringPtr toreply,
          float *f, char divider, uint8_t index) {
  char *p = prog_char_strstr(replybuffer, (prog_char*)toreply);  // get the pointer to the voltage
  if (p == 0) return false;
  p+=prog_char_strlen((prog_char*)toreply);
  //DEBUG_PRINTLN(p);
  for (uint8_t i=0; i<index;i++) {
    // increment dividers
    p = strchr(p, divider);
    if (!p) return false;
    p++;
    //DEBUG_PRINTLN(p);

  }
  *f = atof(p);

  return true;
}

// needed for CBC and others

boolean Adafruit_FONA::sendParseReplyFloat(FONAFlashStringPtr tosend,
				      FONAFlashStringPtr toreply,
				      float *f, char divider, uint8_t index) {
  getReply(tosend);

  if (! parseReplyFloat(toreply, f, divider, index)) return false;

  readline(); // eat 'OK'

  return true;
}





