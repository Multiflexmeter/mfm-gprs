
This directory hosts official Arduino IDE 1.6.3 distribution libs patched for mighty-1284p core compatibility. If/when these libs become mighty-1284p core compatible in a future official distribution, they can be removed from this directory.
